package com.glass.launcher

import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Home { var tick by mutableIntStateOf(0) }
enum class Panel { None, Library, Notifs }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        Home.tick++ // tombol Home ditekan: tutup semua panel
    }

    fun setBlur(r: Int) {
        if (Build.VERSION.SDK_INT >= 31) try { window.setBackgroundBlurRadius(r) } catch (_: Throwable) { }
    }
}

// ---------- Liquid glass ----------
fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(28.dp), alpha: Float = 0.16f) =
    this.clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha + 0.10f), Color.White.copy(alpha - 0.06f))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(0.75f), Color.White.copy(0.05f), Color.White.copy(0.40f))),
            shape,
        )

private val shadowStyle = TextStyle(shadow = Shadow(Color.Black.copy(0.45f), blurRadius = 6f))

// ---------- Root ----------
@Composable
fun LauncherApp() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var reload by remember { mutableIntStateOf(0) }
    var panel by remember { mutableStateOf(Panel.None) }
    var drag by remember { mutableFloatStateOf(0f) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { reload++ }
    LaunchedEffect(reload) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(Home.tick) { panel = Panel.None }
    BackHandler(panel != Panel.None) { panel = Panel.None }

    val blur by animateIntAsState(if (panel == Panel.None) 0 else 60, tween(350), label = "blur")
    SideEffect { (ctx as? MainActivity)?.setBlur(blur) }

    val dock = remember(apps) { defaultDock(ctx, apps) }
    val homeApps = remember(apps, dock) { apps - dock.toSet() }
    val onLaunch: (AppItem, Rect) -> Unit = { a, r -> launchApp(ctx, a, r); panel = Panel.None }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = {
                        if (drag < -250) panel = Panel.Library
                        else if (drag > 250) panel = Panel.Notifs
                    },
                    onVerticalDrag = { _, d -> drag += d },
                )
            }
    ) {
        HomeScreen(homeApps, dock, onLaunch)

        AnimatedVisibility(
            panel == Panel.Library,
            enter = slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) { LibraryPanel(apps, onClose = { panel = Panel.None }, onLaunch = onLaunch) }

        AnimatedVisibility(
            panel == Panel.Notifs,
            enter = slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
        ) { NotifPanel(apps, onClose = { panel = Panel.None }) }
    }
}

// ---------- Home ----------
@Composable
fun HomeScreen(apps: List<AppItem>, dock: List<AppItem>, onLaunch: (AppItem, Rect) -> Unit) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val pages = remember(apps) { apps.chunked(20).ifEmpty { listOf(emptyList()) } }
    val pager = rememberPagerState { pages.size }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Column(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
                color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light, style = shadowStyle)
            Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
                color = Color.White.copy(0.9f), fontSize = 16.sp, style = shadowStyle)
        }

        HorizontalPager(pager, Modifier.weight(1f)) { p ->
            Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                pages[p].chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { Box(Modifier.weight(1f), Alignment.Center) { AppIcon(it, true, onLaunch) } }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }

        if (pages.size > 1) Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), Arrangement.Center) {
            repeat(pages.size) { i ->
                Box(Modifier.padding(3.dp).size(6.dp).clip(CircleShape)
                    .background(Color.White.copy(if (i == pager.currentPage) 0.95f else 0.4f)))
            }
        }

        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth()
                .glass(RoundedCornerShape(32.dp), 0.20f).padding(horizontal = 10.dp, vertical = 8.dp),
            Arrangement.SpaceEvenly,
        ) { dock.take(4).forEach { AppIcon(it, false, onLaunch) } }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(app: AppItem, showLabel: Boolean, onLaunch: (AppItem, Rect) -> Unit) {
    val ctx = LocalContext.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.86f else 1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "press")
    var bounds by remember { mutableStateOf(Rect.Zero) }

    Column(
        Modifier
            .onGloballyPositioned { bounds = it.boundsInWindow() }
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(
                interactionSource = src, indication = null,
                onLongClick = { openAppInfo(ctx, app.pkg) },
                onClick = { onLaunch(app, bounds) },
            )
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(app.icon, app.label, Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)))
        if (showLabel) Text(app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, style = shadowStyle, modifier = Modifier.padding(top = 4.dp).width(70.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

// ---------- App Library + pencarian (geser ke atas) ----------
@Composable
fun LibraryPanel(apps: List<AppItem>, onClose: () -> Unit, onLaunch: (AppItem, Rect) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q, apps) { if (q.isBlank()) apps else apps.filter { it.label.contains(q, true) } }
    var d by remember { mutableFloatStateOf(0f) }

    Column(
        Modifier.fillMaxSize().background(Color.Black.copy(0.35f))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 16.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(32.dp)
            .pointerInput(Unit) {
                detectVerticalDragGestures(onDragStart = { d = 0f }, onDragEnd = { if (d > 80) onClose() },
                    onVerticalDrag = { _, v -> d += v })
            }.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() },
            Alignment.Center) {
            Box(Modifier.width(40.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(0.5f)))
        }
        BasicTextField(
            q, { q = it }, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(14.dp),
            decorationBox = { inner -> if (q.isEmpty()) Text("Cari aplikasi", color = Color.White.copy(0.6f)); inner() },
        )
        LazyVerticalGrid(GridCells.Fixed(4), contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)) {
            items(list, key = { it.component.flattenToString() }) {
                Box(Modifier.fillMaxWidth(), Alignment.Center) { AppIcon(it, true, onLaunch) }
            }
        }
    }
}

// ---------- Pusat notifikasi (geser ke bawah) ----------
@Composable
fun NotifPanel(apps: List<AppItem>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val items by NotifStore.items.collectAsState()
    val enabled = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    var d by remember { mutableFloatStateOf(0f) }
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }

    Column(
        Modifier.fillMaxSize().background(Color.Black.copy(0.35f))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Notifikasi", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            if (items.isNotEmpty()) Text("Hapus semua", color = Color.White.copy(0.85f), fontSize = 14.sp,
                modifier = Modifier.glass(RoundedCornerShape(50), 0.18f)
                    .clickable { NotifStore.service?.cancelAllNotifications() }
                    .padding(horizontal = 14.dp, vertical = 8.dp))
        }

        if (!enabled) {
            Box(Modifier.fillMaxWidth().glass().clickable {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.padding(20.dp)) {
                Text("Ketuk untuk mengaktifkan akses notifikasi", color = Color.White)
            }
        } else if (items.isEmpty()) {
            Text("Tidak ada notifikasi", color = Color.White.copy(0.7f), modifier = Modifier.padding(8.dp))
        }

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.key }) { n ->
                Row(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.18f)
                        .clickable { try { n.intent?.send() } catch (_: Exception) { }; onClose() }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    byPkg[n.pkg]?.let {
                        Image(it.icon, null, Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)))
                        Spacer(Modifier.width(12.dp))
                    }
                    Column {
                        Text(n.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (n.text.isNotBlank()) Text(n.text, color = Color.White.copy(0.85f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Box(Modifier.fillMaxWidth().height(36.dp)
            .pointerInput(Unit) {
                detectVerticalDragGestures(onDragStart = { d = 0f }, onDragEnd = { if (d < -80) onClose() },
                    onVerticalDrag = { _, v -> d += v })
            }.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() },
            Alignment.Center) {
            Box(Modifier.width(40.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(0.5f)))
        }
    }
}
