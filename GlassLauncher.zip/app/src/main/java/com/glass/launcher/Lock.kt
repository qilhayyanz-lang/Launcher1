package com.glass.launcher

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- Service: mendengar layar mati, lalu menampilkan lock screen ----------
class LockService : Service() {
    private var dot: View? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF && Prefs.lockEnabled) {
                try {
                    c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) { }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "Lock screen", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Lock screen aktif").build()
        ServiceCompat.startForeground(this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        ContextCompat.registerReceiver(this, receiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED)
        // Jendela overlay 1x1 transparan: syarat agar boleh membuka activity dari latar belakang.
        try {
            val v = View(this)
            val lp = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT)
            getSystemService(WindowManager::class.java).addView(v, lp)
            dot = v
        } catch (_: Exception) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        try { dot?.let { getSystemService(WindowManager::class.java).removeView(it) } } catch (_: Exception) { }
        super.onDestroy()
    }

    companion object {
        fun sync(ctx: Context) {
            val i = Intent(ctx, LockService::class.java)
            if (Prefs.lockEnabled && Settings.canDrawOverlays(ctx)) {
                try { ContextCompat.startForegroundService(ctx, i) } catch (_: Exception) { }
            } else ctx.stopService(i)
        }
    }
}

// ---------- Activity lock screen ----------
class LockActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        enableEdgeToEdge()
        Prefs.init(this)
        setContent { LockScreen(onUnlock = { unlock() }, onCamera = { openCamera() }) }
    }

    private fun dismiss() {
        val km = getSystemService(KeyguardManager::class.java)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissError() { finish() }
        })
    }

    private fun unlock() {
        val km = getSystemService(KeyguardManager::class.java)
        val strong = BiometricManager.Authenticators.BIOMETRIC_STRONG
        if (!km.isDeviceSecure && Prefs.lockBiometric &&
            BiometricManager.from(this).canAuthenticate(strong) == BiometricManager.BIOMETRIC_SUCCESS) {
            val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { dismiss() }
                })
            prompt.authenticate(
                BiometricPrompt.PromptInfo.Builder().setTitle("Buka kunci")
                    .setNegativeButtonText("Batal").setAllowedAuthenticators(strong).build())
        } else dismiss()
    }

    private fun openCamera() {
        try {
            startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }
}

private fun setTorch(ctx: Context, on: Boolean) {
    try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id != null) cm.setTorchMode(id, on)
    } catch (_: Exception) { }
}

@Composable
fun LockScreen(onUnlock: () -> Unit, onCamera: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    var now by remember { mutableStateOf(Date()) }
    var torch by remember { mutableStateOf(false) }
    val notifs by NotifStore.items.collectAsState()
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(5_000) } }
    BackHandler(true) { }
    DisposableEffect(Unit) { onDispose { if (torch) setTorch(ctx, false) } }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color.Black.copy(0.35f), Color.Transparent, Color.Black.copy(0.50f))))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (off.value < -350f) onUnlock()
                        scope.launch { off.animateTo(0f, spring(stiffness = 120f)) }
                    },
                    onVerticalDrag = { change, d ->
                        change.consume()
                        scope.launch { off.snapTo((off.value + d).coerceAtMost(0f)) }
                    },
                )
            }
    ) {
        Column(
            Modifier.fillMaxSize().graphicsLayer {
                translationY = off.value
                alpha = (1f + off.value / 1100f).coerceIn(0f, 1f)
            }.statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(36.dp))
            Text("🔒", fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
                color = Color.White.copy(0.85f), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(SimpleDateFormat("H:mm", Locale.getDefault()).format(now),
                color = Color.White.copy(0.92f), fontSize = 100.sp, fontWeight = FontWeight.SemiBold)

            Spacer(Modifier.weight(1f))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                notifs.take(4).forEach { n ->
                    val app = remember(n.pkg) {
                        try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(n.pkg, 0)).toString() }
                        catch (_: Exception) { n.pkg }
                    }
                    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.20f).padding(14.dp)) {
                        Text(app, color = Color.White.copy(0.7f), fontSize = 11.sp, maxLines = 1)
                        Text(n.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (n.text.isNotBlank()) Text(n.text, color = Color.White.copy(0.85f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                RoundBtn("🔦", torch) { torch = !torch; setTorch(ctx, torch) }
                Text("Geser ke atas untuk membuka", color = Color.White.copy(0.75f), fontSize = 13.sp, textAlign = TextAlign.Center)
                RoundBtn("📷", false) { onCamera() }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun RoundBtn(icon: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(50.dp).glass(CircleShape, if (active) 0.55f else 0.20f).clickable { onClick() },
        Alignment.Center,
    ) { Text(icon, fontSize = 20.sp) }
}
