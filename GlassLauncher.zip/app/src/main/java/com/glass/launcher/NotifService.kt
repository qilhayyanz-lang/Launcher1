package com.glass.launcher

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

data class NotifItem(
    val key: String,
    val pkg: String,
    val title: String,
    val text: String,
    val intent: PendingIntent?,
    val time: Long,
)

object NotifStore {
    val items = MutableStateFlow<List<NotifItem>>(emptyList())
    var service: NotifService? = null
}

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() { NotifStore.service = this; refresh() }
    override fun onListenerDisconnected() { NotifStore.service = null }
    override fun onNotificationPosted(sbn: StatusBarNotification) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refresh()

    private fun refresh() {
        NotifStore.items.value = try {
            activeNotifications.orEmpty()
                .filter { (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 && it.packageName != packageName }
                .sortedByDescending { it.postTime }
                .map {
                    val e = it.notification.extras
                    NotifItem(
                        it.key, it.packageName,
                        e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
                        e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
                        it.notification.contentIntent, it.postTime,
                    )
                }
        } catch (_: Exception) { emptyList() }
    }
}
