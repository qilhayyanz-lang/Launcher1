package com.glass.launcher

import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.provider.Settings
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

object Prefs {
    private var sp: SharedPreferences? = null
    var iconDp by mutableIntStateOf(60)
    var showLabels by mutableStateOf(true)
    var showClock by mutableStateOf(false)
    var lockEnabled by mutableStateOf(false)
    var lockBiometric by mutableStateOf(false)

    fun init(c: Context) {
        val s = c.getSharedPreferences("glass", Context.MODE_PRIVATE)
        sp = s
        iconDp = s.getInt("iconDp", 60)
        showLabels = s.getBoolean("labels", true)
        showClock = s.getBoolean("clock", false)
        lockEnabled = s.getBoolean("lock", false)
        lockBiometric = s.getBoolean("lockBio", false)
    }

    fun save() {
        sp?.edit()?.putInt("iconDp", iconDp)?.putBoolean("labels", showLabels)?.putBoolean("clock", showClock)?.putBoolean("lock", lockEnabled)?.putBoolean("lockBio", lockBiometric)?.apply()
    }
}

/** Bentuk ikon iOS (superellipse / squircle). */
val Squircle = GenericShape { size, _ ->
    val n = 5.0
    val steps = 96
    val a = size.width / 2.0
    val b = size.height / 2.0
    for (i in 0..steps) {
        val t = 2 * PI * i / steps
        val c = cos(t)
        val s = sin(t)
        val x = (a + a * sign(c) * abs(c).pow(2 / n)).toFloat()
        val y = (b + b * sign(s) * abs(s).pow(2 / n)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

fun setWallpaper(ctx: Context, uri: Uri, which: Int): Boolean = try {
    ctx.contentResolver.openInputStream(uri)?.use {
        WallpaperManager.getInstance(ctx).setStream(it, null, true, which)
    }
    true
} catch (_: Exception) { false }

@Composable
fun SettingsPanel(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var target by remember { mutableIntStateOf(WallpaperManager.FLAG_SYSTEM) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { setWallpaper(ctx, uri, target) }
            Toast.makeText(ctx, if (ok) "Wallpaper diganti" else "Gagal mengganti wallpaper", Toast.LENGTH_SHORT).show()
        }
    }
    fun pick(flag: Int) { target = flag; picker.launch("image/*") }

    Column(
        Modifier.fillMaxSize().background(Color.Black.copy(0.45f))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Pengaturan", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Selesai", color = Color.White, fontSize = 14.sp,
                modifier = Modifier.glass(RoundedCornerShape(50), 0.2f).clickable { onClose() }
                    .padding(horizontal = 16.dp, vertical = 8.dp))
        }

        SettingCard {
            Text("Wallpaper", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Layar utama", false, Modifier.weight(1f)) { pick(WallpaperManager.FLAG_SYSTEM) }
                Chip("Layar kunci", false, Modifier.weight(1f)) { pick(WallpaperManager.FLAG_LOCK) }
                Chip("Keduanya", false, Modifier.weight(1f)) { pick(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK) }
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingCard {
            Text("Ukuran ikon", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Kecil" to 54, "Normal" to 60, "Besar" to 66).forEach { (label, dp) ->
                    Chip(label, Prefs.iconDp == dp, Modifier.weight(1f)) { Prefs.iconDp = dp; Prefs.save() }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingCard {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Nama aplikasi", color = Color.White)
                Toggle(Prefs.showLabels) { Prefs.showLabels = it; Prefs.save() }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Jam di layar utama", color = Color.White)
                Toggle(Prefs.showClock) { Prefs.showClock = it; Prefs.save() }
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingCard {
            Text("Lock screen", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Lock screen gaya iPhone", color = Color.White, modifier = Modifier.weight(1f))
                Toggle(Prefs.lockEnabled) { on ->
                    if (on && !Settings.canDrawOverlays(ctx)) {
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        Toast.makeText(ctx, "Izinkan 'tampil di atas aplikasi lain', lalu aktifkan lagi", Toast.LENGTH_LONG).show()
                    } else {
                        Prefs.lockEnabled = on; Prefs.save(); LockService.sync(ctx)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Sidik jari sendiri (hanya jika kunci sistem = Tidak ada/Geser)", color = Color.White, fontSize = 14.sp,
                    modifier = Modifier.weight(1f).padding(end = 12.dp))
                Toggle(Prefs.lockBiometric) { Prefs.lockBiometric = it; Prefs.save() }
            }
            Spacer(Modifier.height(14.dp))
            Chip("Coba lock screen sekarang", false, Modifier.fillMaxWidth()) {
                ctx.startActivity(Intent(ctx, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        Text("Tekan lama area kosong di layar utama untuk membuka pengaturan ini.",
            color = Color.White.copy(0.65f), fontSize = 12.sp, modifier = Modifier.padding(12.dp))
    }
}

@Composable
private fun SettingCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.18f).padding(16.dp), content = content)
}

@Composable
private fun Chip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.glass(RoundedCornerShape(14.dp), if (selected) 0.40f else 0.16f)
            .clickable { onClick() }.padding(vertical = 12.dp),
        Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) }
}

@Composable
private fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 20.dp else 0.dp, spring(dampingRatio = 0.7f, stiffness = 500f), label = "toggle")
    Box(
        Modifier.width(51.dp).height(31.dp).clip(CircleShape)
            .background(if (on) Color(0xFF34C759) else Color.White.copy(0.25f))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onChange(!on) }
            .padding(2.dp)
    ) { Box(Modifier.offset(x).size(27.dp).clip(CircleShape).background(Color.White)) }
}
