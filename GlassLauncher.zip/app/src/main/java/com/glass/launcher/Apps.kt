package com.glass.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

data class AppItem(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

private val iconCache = HashMap<String, ImageBitmap>()

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            val icon = synchronized(iconCache) {
                iconCache.getOrPut(cn.flattenToString()) { iosIcon(ri.loadIcon(pm), 192) }
            }
            AppItem(ri.loadLabel(pm).toString(), cn.packageName, cn, icon)
        }
        .sortedBy { it.label.lowercase() }
}

/** Dock default: telepon, pesan, browser, kamera (kalau ditemukan). */
fun defaultDock(ctx: Context, apps: List<AppItem>): List<AppItem> {
    val pm = ctx.packageManager
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(Intent.ACTION_VIEW, Uri.parse("http://")),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE),
    )
    return intents
        .mapNotNull { pm.resolveActivity(it, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .distinct()
        .mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
}

fun launchApp(ctx: Context, app: AppItem, r: Rect) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try {
        val opts = (ctx as? Activity)?.let {
            ActivityOptions.makeScaleUpAnimation(
                it.window.decorView, r.left.toInt(), r.top.toInt(), r.width.toInt(), r.height.toInt(),
            ).toBundle()
        }
        ctx.startActivity(i, opts)
    } catch (_: Exception) { }
}

fun openAppInfo(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}

/** Ikon adaptif dipotong ke area penuh (tanpa mask lingkaran) supaya pas dengan squircle iOS. */
fun iosIcon(d: Drawable, size: Int): ImageBitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
        val full = (size * 108f / 72f).toInt()
        val off = (size - full) / 2
        d.background?.apply { setBounds(off, off, off + full, off + full); draw(c) }
        d.foreground?.apply { setBounds(off, off, off + full, off + full); draw(c) }
    } else {
        c.drawColor(android.graphics.Color.WHITE)
        val pad = (size * 0.12f).toInt()
        d.setBounds(pad, pad, size - pad, size - pad)
        d.draw(c)
    }
    return bmp.asImageBitmap()
}
